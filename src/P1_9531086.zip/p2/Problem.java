package p2;

public class Problem {
    public static void main(String[] args) {

//        Graph g = new Graph();
        Genetics genetics = new Genetics();
//        SimpleHillClimbing SHC = new SimpleHillClimbing();
//        BestFirstHillClimbing BFHC = new BestFirstHillClimbing();
//        RandomHillClimbing RHC = new RandomHillClimbing();
//        SimulatedAnnealing SA = new SimulatedAnnealing();
//        RandomRestartHillClimbing RRHC = new RandomRestartHillClimbing();
    }

}
