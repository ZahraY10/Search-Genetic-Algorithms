package p1;

//Class for defining a group of actions used for defining the final path
import java.util.Vector;

public class Action_set_p1 {

	Vector <Action_p1> action_set;
	public Action_set_p1() {
		this.action_set = new Vector<Action_p1>();
	}
}
