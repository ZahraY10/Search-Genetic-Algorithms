package algorithms;

import java.util.Vector;

public class Node {

	State state;
	Vector<Node> next_nodes;
	Vector<Node> parent_nodes;
	String id;
	int f;
	int h;
	int pathCost;
	int length;
	Vector <Node> visited_nodes;
	
	public void next_node(){
		
	}
	
	public void parent_node(){
		
	}
}
