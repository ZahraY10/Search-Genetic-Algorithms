package algorithms;

public class State {

}
