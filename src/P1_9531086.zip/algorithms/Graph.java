package algorithms;

public class Graph {

	Node init;
	Node Goal;
	public Graph() {
		// TODO Auto-generated constructor stub
	}
	
	public boolean Goal_Test(State s){
		return true;
	}
	
	public void print(Node n){
		
	}
	
	public void printB(Node n1, Node n2){
		
	}
}
